# 선형대수 문제 검수본

Template: `linear_algebra.la_01_matrix_algebra.la.matrix.rank.matrix_rank_property.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

m=5, n=4일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
4
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

m=2, n=1일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
1
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

m=6, n=1일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
1
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

m=6, n=6일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
6
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

m=2, n=4일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
2
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

m=2, n=2일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
2
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

m=3, n=1일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
1
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

m=6, n=4일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
4
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

m=4, n=1일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
1
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

m=6, n=2일 때 m x n 행렬이 가질 수 있는 최대 랭크를 구하시오.

**정답**

```json
2
```
