# 선형대수 문제 검수본

Template: `linear_algebra.la_04_orthogonality_optimization.la.ortho.linear_regression.linear_regression_calculation.v1`

## 1. 시작 seed 17 (실제 seed 19)

[전체 JSON](start_17_actual_19.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, -4], [1, -2], [1, 0]]), y = Matrix([[6], [-1], [8]])

**정답**

```json
[
  [
    "16/3"
  ],
  [
    "1/2"
  ]
]
```

## 2. 시작 seed 20 (실제 seed 21)

[전체 JSON](start_20_actual_21.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, 1], [1, -1], [1, -2]]), y = Matrix([[5], [6], [-5]])

**정답**

```json
[
  [
    "27/7"
  ],
  [
    "39/14"
  ]
]
```

## 3. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, -5], [1, 2], [1, -4]]), y = Matrix([[10], [1], [-8]])

**정답**

```json
[
  [
    "23/86"
  ],
  [
    "-27/86"
  ]
]
```

## 4. 시작 seed 23 (실제 seed 31)

[전체 JSON](start_23_actual_31.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, -4], [1, -3], [1, -5]]), y = Matrix([[-6], [-7], [7]])

**정답**

```json
[
  [
    -30
  ],
  [
    -7
  ]
]
```

## 5. 시작 seed 32 (실제 seed 38)

[전체 JSON](start_32_actual_38.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, -4], [1, 0], [1, 0], [1, 4]]), y = Matrix([[-5], [8], [1], [0]])

**정답**

```json
[
  [
    1
  ],
  [
    "5/8"
  ]
]
```

## 6. 시작 seed 39 (실제 seed 39)

[전체 JSON](start_39_actual_39.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, 1], [1, -2], [1, 1]]), y = Matrix([[8], [-10], [10]])

**정답**

```json
[
  [
    "8/3"
  ],
  [
    "19/3"
  ]
]
```

## 7. 시작 seed 40 (실제 seed 49)

[전체 JSON](start_40_actual_49.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, 1], [1, 0], [1, 3]]), y = Matrix([[-9], [-9], [-2]])

**정답**

```json
[
  [
    -10
  ],
  [
    "5/2"
  ]
]
```

## 8. 시작 seed 50 (실제 seed 50)

[전체 JSON](start_50_actual_50.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, 0], [1, -2], [1, 0], [1, 3]]), y = Matrix([[0], [-3], [7], [-8]])

**정답**

```json
[
  [
    "-2/3"
  ],
  [
    "-4/3"
  ]
]
```

## 9. 시작 seed 51 (실제 seed 53)

[전체 JSON](start_51_actual_53.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, 3], [1, 3], [1, 2]]), y = Matrix([[-10], [-9], [-5]])

**정답**

```json
[
  [
    4
  ],
  [
    "-9/2"
  ]
]
```

## 10. 시작 seed 54 (실제 seed 62)

[전체 JSON](start_54_actual_62.json)

**문제**

설계행렬 X와 관측벡터 y에 대한 최소제곱 회귀계수 beta_hat을 구하시오.
X = Matrix([[1, -2], [1, -1], [1, 0]]), y = Matrix([[-5], [6], [-5]])

**정답**

```json
[
  [
    "-4/3"
  ],
  [
    0
  ]
]
```
