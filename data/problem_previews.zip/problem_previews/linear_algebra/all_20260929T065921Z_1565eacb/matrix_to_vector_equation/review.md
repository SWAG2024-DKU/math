# 선형대수 문제 검수본

Template: `linear_algebra.la_01_matrix_algebra.la.matrix.system_form.matrix_to_vector_equation.v1`
