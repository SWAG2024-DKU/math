# 선형대수 문제 검수본

Template: `linear_algebra.la_01_matrix_algebra.la.matrix.lu_decomposition.solve_by_lu.v1`

## 1. 시작 seed 17 (실제 seed 18)

[전체 JSON](start_17_actual_18.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[-4, 5], [2, 0]]), b = Matrix([[-1], [-2]])

**정답**

```json
[
  [
    -1
  ],
  [
    -1
  ]
]
```

## 2. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[3, -4], [3, -2]]), b = Matrix([[4], [3]])

**정답**

```json
[
  [
    "2/3"
  ],
  [
    "-1/2"
  ]
]
```

## 3. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[-1, 5], [5, -4]]), b = Matrix([[2], [-3]])

**정답**

```json
[
  [
    "-1/3"
  ],
  [
    "1/3"
  ]
]
```

## 4. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[1, 1], [5, -1]]), b = Matrix([[7], [-2]])

**정답**

```json
[
  [
    "5/6"
  ],
  [
    "37/6"
  ]
]
```

## 5. 시작 seed 22 (실제 seed 30)

[전체 JSON](start_22_actual_30.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[4, -5, 4], [5, -2, -1], [-5, 1, 1]]), b = Matrix([[-4], [-6], [6]])

**정답**

```json
[
  [
    "-7/6"
  ],
  [
    0
  ],
  [
    "1/6"
  ]
]
```

## 6. 시작 seed 31 (실제 seed 31)

[전체 JSON](start_31_actual_31.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[2, -4], [1, -3]]), b = Matrix([[-7], [-4]])

**정답**

```json
[
  [
    "-5/2"
  ],
  [
    "1/2"
  ]
]
```

## 7. 시작 seed 32 (실제 seed 32)

[전체 JSON](start_32_actual_32.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[-2, -3], [-1, -2]]), b = Matrix([[7], [-8]])

**정답**

```json
[
  [
    -38
  ],
  [
    23
  ]
]
```

## 8. 시작 seed 33 (실제 seed 33)

[전체 JSON](start_33_actual_33.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[5, -2], [-1, 2]]), b = Matrix([[8], [-3]])

**정답**

```json
[
  [
    "5/4"
  ],
  [
    "-7/8"
  ]
]
```

## 9. 시작 seed 34 (실제 seed 35)

[전체 JSON](start_34_actual_35.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[-3, 0, -3], [-1, 1, -1], [4, -5, 3]]), b = Matrix([[0], [3], [-5]])

**정답**

```json
[
  [
    10
  ],
  [
    3
  ],
  [
    -10
  ]
]
```

## 10. 시작 seed 36 (실제 seed 39)

[전체 JSON](start_36_actual_39.json)

**문제**

LU 분해와 전진/후진대입을 사용하여 A x = b의 해 x를 구하시오.
A = Matrix([[-1, 1], [-5, -2]]), b = Matrix([[-1], [4]])

**정답**

```json
[
  [
    "-2/7"
  ],
  [
    "-9/7"
  ]
]
```
