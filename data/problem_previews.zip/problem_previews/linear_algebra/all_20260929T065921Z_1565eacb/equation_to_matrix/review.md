# 선형대수 문제 검수본

Template: `linear_algebra.la_01_matrix_algebra.la.matrix.system_form.equation_to_matrix.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[3, 1], [-1, 0]]), b = Matrix([[0], [-4]])

**정답**

```json
[
  [
    3,
    1,
    0
  ],
  [
    -1,
    0,
    -4
  ]
]
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[-3, -4], [5, 2]]), b = Matrix([[1], [-2]])

**정답**

```json
[
  [
    -3,
    -4,
    1
  ],
  [
    5,
    2,
    -2
  ]
]
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[5, -5], [3, -4]]), b = Matrix([[7], [-3]])

**정답**

```json
[
  [
    5,
    -5,
    7
  ],
  [
    3,
    -4,
    -3
  ]
]
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[5, -3], [-1, 5]]), b = Matrix([[-6], [1]])

**정답**

```json
[
  [
    5,
    -3,
    -6
  ],
  [
    -1,
    5,
    1
  ]
]
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[-3, 1], [1, 5]]), b = Matrix([[0], [6]])

**정답**

```json
[
  [
    -3,
    1,
    0
  ],
  [
    1,
    5,
    6
  ]
]
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[-3, -2], [-5, 4]]), b = Matrix([[5], [-4]])

**정답**

```json
[
  [
    -3,
    -2,
    5
  ],
  [
    -5,
    4,
    -4
  ]
]
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[-1, -4], [-5, 4]]), b = Matrix([[0], [4]])

**정답**

```json
[
  [
    -1,
    -4,
    0
  ],
  [
    -5,
    4,
    4
  ]
]
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[1, 4], [-3, -2]]), b = Matrix([[-4], [-3]])

**정답**

```json
[
  [
    1,
    4,
    -4
  ],
  [
    -3,
    -2,
    -3
  ]
]
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[1, -5], [-2, -1]]), b = Matrix([[6], [-8]])

**정답**

```json
[
  [
    1,
    -5,
    6
  ],
  [
    -2,
    -1,
    -8
  ]
]
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

다음 연립일차방정식 A x = b에 대응하는 첨가행렬 [A | b]를 구하시오.
A = Matrix([[-2, 5], [-2, 1]]), b = Matrix([[8], [-8]])

**정답**

```json
[
  [
    -2,
    5,
    8
  ],
  [
    -2,
    1,
    -8
  ]
]
```
