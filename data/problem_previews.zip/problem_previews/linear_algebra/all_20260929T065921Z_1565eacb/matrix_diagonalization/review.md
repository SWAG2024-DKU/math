# 선형대수 문제 검수본

Template: `linear_algebra.la_05_eigenvalues_diagonalization.la.eigen.diagonalization.matrix_diagonalization.v1`

## 1. 시작 seed 17 (실제 seed 18)

[전체 JSON](start_17_actual_18.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[-3, 3], [1, -1]])

**정답**

```json
[
  [
    [
      -3,
      1
    ],
    [
      1,
      1
    ]
  ],
  [
    [
      -4,
      0
    ],
    [
      0,
      0
    ]
  ]
]
```

## 2. 시작 seed 19 (실제 seed 21)

[전체 JSON](start_19_actual_21.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[2, 2], [0, 3]])

**정답**

```json
[
  [
    [
      1,
      2
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      2,
      0
    ],
    [
      0,
      3
    ]
  ]
]
```

## 3. 시작 seed 22 (실제 seed 29)

[전체 JSON](start_22_actual_29.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[1, 0], [-3, 4]])

**정답**

```json
[
  [
    [
      1,
      0
    ],
    [
      1,
      1
    ]
  ],
  [
    [
      1,
      0
    ],
    [
      0,
      4
    ]
  ]
]
```

## 4. 시작 seed 30 (실제 seed 31)

[전체 JSON](start_30_actual_31.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[3, -3], [2, -2]])

**정답**

```json
[
  [
    [
      1,
      3
    ],
    [
      1,
      2
    ]
  ],
  [
    [
      0,
      0
    ],
    [
      0,
      1
    ]
  ]
]
```

## 5. 시작 seed 32 (실제 seed 33)

[전체 JSON](start_32_actual_33.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[-1, 0], [3, 4]])

**정답**

```json
[
  [
    [
      -5,
      0
    ],
    [
      3,
      1
    ]
  ],
  [
    [
      -1,
      0
    ],
    [
      0,
      4
    ]
  ]
]
```

## 6. 시작 seed 34 (실제 seed 42)

[전체 JSON](start_34_actual_42.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[-4, 0], [-1, -1]])

**정답**

```json
[
  [
    [
      3,
      0
    ],
    [
      1,
      1
    ]
  ],
  [
    [
      -4,
      0
    ],
    [
      0,
      -1
    ]
  ]
]
```

## 7. 시작 seed 43 (실제 seed 53)

[전체 JSON](start_43_actual_53.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[3, 4], [3, 4]])

**정답**

```json
[
  [
    [
      -4,
      1
    ],
    [
      3,
      1
    ]
  ],
  [
    [
      0,
      0
    ],
    [
      0,
      7
    ]
  ]
]
```

## 8. 시작 seed 54 (실제 seed 55)

[전체 JSON](start_54_actual_55.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[-1, -2], [0, -3]])

**정답**

```json
[
  [
    [
      1,
      1
    ],
    [
      1,
      0
    ]
  ],
  [
    [
      -3,
      0
    ],
    [
      0,
      -1
    ]
  ]
]
```

## 9. 시작 seed 56 (실제 seed 56)

[전체 JSON](start_56_actual_56.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[3, 4], [0, 4]])

**정답**

```json
[
  [
    [
      1,
      4
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      3,
      0
    ],
    [
      0,
      4
    ]
  ]
]
```

## 10. 시작 seed 57 (실제 seed 57)

[전체 JSON](start_57_actual_57.json)

**문제**

행렬 A를 A=PDP^{-1} 형태로 대각화하고 P와 D를 구하시오.
A = Matrix([[1, -4], [-1, 4]])

**정답**

```json
[
  [
    [
      4,
      -1
    ],
    [
      1,
      1
    ]
  ],
  [
    [
      0,
      0
    ],
    [
      0,
      5
    ]
  ]
]
```
