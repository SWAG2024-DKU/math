# 선형대수 문제 검수본

Template: `linear_algebra.la_05_eigenvalues_diagonalization.la.eigen.symmetric_diagonalization.orthogonal_diagonalization_calculation.v1`

## 1. 시작 seed 17 (실제 seed 29)

[전체 JSON](start_17_actual_29.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[1, 0], [0, -3]])

**정답**

```json
[
  [
    [
      0,
      1
    ],
    [
      1,
      0
    ]
  ],
  [
    [
      -3,
      0
    ],
    [
      0,
      1
    ]
  ]
]
```

## 2. 시작 seed 30 (실제 seed 33)

[전체 JSON](start_30_actual_33.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[-1, 0], [0, 3]])

**정답**

```json
[
  [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      -1,
      0
    ],
    [
      0,
      3
    ]
  ]
]
```

## 3. 시작 seed 34 (실제 seed 42)

[전체 JSON](start_34_actual_42.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[-4, 0], [0, -1]])

**정답**

```json
[
  [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      -4,
      0
    ],
    [
      0,
      -1
    ]
  ]
]
```

## 4. 시작 seed 43 (실제 seed 78)

[전체 JSON](start_43_actual_78.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[-3, 0], [0, 0]])

**정답**

```json
[
  [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      -3,
      0
    ],
    [
      0,
      0
    ]
  ]
]
```

## 6. 시작 seed 95 (실제 seed 125)

[전체 JSON](start_95_actual_125.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[-1, 0], [0, -2]])

**정답**

```json
[
  [
    [
      0,
      1
    ],
    [
      1,
      0
    ]
  ],
  [
    [
      -2,
      0
    ],
    [
      0,
      -1
    ]
  ]
]
```

## 7. 시작 seed 126 (실제 seed 139)

[전체 JSON](start_126_actual_139.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[4, 0], [0, 4]])

**정답**

```json
[
  [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      4,
      0
    ],
    [
      0,
      4
    ]
  ]
]
```

## 8. 시작 seed 140 (실제 seed 140)

[전체 JSON](start_140_actual_140.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[-4, 0], [0, -4]])

**정답**

```json
[
  [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      -4,
      0
    ],
    [
      0,
      -4
    ]
  ]
]
```

## 9. 시작 seed 141 (실제 seed 149)

[전체 JSON](start_141_actual_149.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[-3, 0], [0, 2]])

**정답**

```json
[
  [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      -3,
      0
    ],
    [
      0,
      2
    ]
  ]
]
```

## 10. 시작 seed 150 (실제 seed 164)

[전체 JSON](start_150_actual_164.json)

**문제**

실수 대칭행렬 A를 A=QDQ^T 형태로 직교대각화하고 Q와 D를 구하시오.
A = Matrix([[0, 0], [0, 3]])

**정답**

```json
[
  [
    [
      1,
      0
    ],
    [
      0,
      1
    ]
  ],
  [
    [
      0,
      0
    ],
    [
      0,
      3
    ]
  ]
]
```
