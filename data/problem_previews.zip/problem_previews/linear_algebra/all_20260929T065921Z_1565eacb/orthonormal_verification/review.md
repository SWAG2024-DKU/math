# 선형대수 문제 검수본

Template: `linear_algebra.la_04_orthogonality_optimization.la.ortho.orthonormal_set.orthonormal_verification.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[1, 0], [3, -1], [-1, -1]])

**정답**

```json
false
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[-2, -3], [2, 0], [-1, -2]])

**정답**

```json
false
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[2, -3], [3, 1], [-3, 1]])

**정답**

```json
false
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[2, 2], [3, 3], [-2, -1]])

**정답**

```json
false
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[-2, 0], [2, 0], [2, -1]])

**정답**

```json
false
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[-2, -2], [-3, 1], [0, -2]])

**정답**

```json
false
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[3, -1], [3, -3], [-3, 1]])

**정답**

```json
false
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[2, 0], [3, 1], [-2, -2]])

**정답**

```json
false
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[0, 3], [3, 3], [-3, -2]])

**정답**

```json
false
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

Q의 열벡터들이 정규직교집합인지 판정하시오.
Q = Matrix([[2, -2], [2, -2], [0, 1]])

**정답**

```json
false
```
