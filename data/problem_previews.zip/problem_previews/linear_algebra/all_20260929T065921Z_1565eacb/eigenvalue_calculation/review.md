# 선형대수 문제 검수본

Template: `linear_algebra.la_05_eigenvalues_diagonalization.la.eigen.eigenvalue.eigenvalue_calculation.v1`

## 1. 시작 seed 17 (실제 seed 31)

[전체 JSON](start_17_actual_31.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[2, -4], [1, -3]])

**정답**

```json
[
  1,
  -2
]
```

## 2. 시작 seed 32 (실제 seed 40)

[전체 JSON](start_32_actual_40.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[4, 3, -5], [-2, -1, 5], [5, 5, -2]])

**정답**

```json
[
  2,
  1,
  -2
]
```

## 3. 시작 seed 41 (실제 seed 53)

[전체 JSON](start_41_actual_53.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[2, 3], [2, 3]])

**정답**

```json
[
  5,
  0
]
```

## 4. 시작 seed 54 (실제 seed 55)

[전체 JSON](start_54_actual_55.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[-2, -3], [-1, -4]])

**정답**

```json
[
  -1,
  -5
]
```

## 5. 시작 seed 56 (실제 seed 61)

[전체 JSON](start_56_actual_61.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[-3, 3, -2], [0, -1, 0], [-5, 2, 0]])

**정답**

```json
[
  -1,
  2,
  -5
]
```

## 6. 시작 seed 62 (실제 seed 66)

[전체 JSON](start_62_actual_66.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[-1, 1], [-2, 2]])

**정답**

```json
[
  1,
  0
]
```

## 7. 시작 seed 67 (실제 seed 72)

[전체 JSON](start_67_actual_72.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[4, -3], [0, 3]])

**정답**

```json
[
  3,
  4
]
```

## 8. 시작 seed 73 (실제 seed 74)

[전체 JSON](start_73_actual_74.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[0, -4], [-1, -3]])

**정답**

```json
[
  1,
  -4
]
```

## 9. 시작 seed 75 (실제 seed 79)

[전체 JSON](start_75_actual_79.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[2, 0], [4, -3]])

**정답**

```json
[
  2,
  -3
]
```

## 10. 시작 seed 80 (실제 seed 85)

[전체 JSON](start_80_actual_85.json)

**문제**

행렬 A의 고윳값들을 구하시오.
A = Matrix([[4, -4], [0, -2]])

**정답**

```json
[
  -2,
  4
]
```
