# 선형대수 문제 검수본

Template: `linear_algebra.la_05_eigenvalues_diagonalization.la.eigen.positive_definite.positive_definite_test.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[0, 1, 0], [1, -2, 4], [0, 4, 0]])

**정답**

```json
false
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[-3, 3], [3, 1]])

**정답**

```json
false
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[4, -3], [-3, 4]])

**정답**

```json
true
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[0, -3], [-3, 1]])

**정답**

```json
false
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[2, 2], [2, 0]])

**정답**

```json
false
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[-1, -4], [-4, 3]])

**정답**

```json
false
```

## 7. 시작 seed 23 (실제 seed 26)

[전체 JSON](start_23_actual_26.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[-1, 2], [2, 4]])

**정답**

```json
false
```

## 8. 시작 seed 27 (실제 seed 28)

[전체 JSON](start_27_actual_28.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[-2, 4], [4, -2]])

**정답**

```json
false
```

## 9. 시작 seed 29 (실제 seed 29)

[전체 JSON](start_29_actual_29.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[1, 0], [0, -3]])

**정답**

```json
false
```

## 10. 시작 seed 30 (실제 seed 31)

[전체 JSON](start_30_actual_31.json)

**문제**

실수 대칭행렬 A가 양의 정부호(positive definite)인지 판정하시오.
A = Matrix([[3, -3], [-3, 2]])

**정답**

```json
false
```
