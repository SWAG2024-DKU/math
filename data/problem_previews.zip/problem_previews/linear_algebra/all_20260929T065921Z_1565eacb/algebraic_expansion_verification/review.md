# 선형대수 문제 검수본

Template: `linear_algebra.la_01_matrix_algebra.la.matrix.multiplication.algebraic_expansion_verification.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

행렬 곱셈의 비교환성을 고려하여 (A+B)^2를 전개하시오.

**정답**

```json
[
  [
    10,
    21,
    6
  ],
  [
    4,
    31,
    0
  ],
  [
    15,
    -15,
    25
  ]
]
```
