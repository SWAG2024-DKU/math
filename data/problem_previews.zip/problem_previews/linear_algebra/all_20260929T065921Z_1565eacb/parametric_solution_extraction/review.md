# 선형대수 문제 검수본

Template: `linear_algebra.la_01_matrix_algebra.la.matrix.parametric_solution.parametric_solution_extraction.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[3, 1, -1], [0, -1, -3]]), b = Matrix([[0], [-5]])

**정답**

```json
"{(4*tau0/3 - 5/3, 5 - 3*tau0, tau0)}"
```

## 2. 시작 seed 18 (실제 seed 25)

[전체 JSON](start_18_actual_25.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[1, -5, -2], [-1, 5, 2]]), b = Matrix([[-7], [0]])

**정답**

```json
"EmptySet"
```

## 3. 시작 seed 26 (실제 seed 28)

[전체 JSON](start_26_actual_28.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[-4, -3, 3], [4, -3, -2]]), b = Matrix([[-4], [6]])

**정답**

```json
"{(5*tau0/8 + 5/4, tau0/6 - 1/3, tau0)}"
```

## 4. 시작 seed 29 (실제 seed 35)

[전체 JSON](start_29_actual_35.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[3, 0, -3], [0, -3, -1]]), b = Matrix([[5], [0]])

**정답**

```json
"{(tau0 + 5/3, -tau0/3, tau0)}"
```

## 5. 시작 seed 36 (실제 seed 39)

[전체 JSON](start_36_actual_39.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[-2, -1, 1], [-5, -2, -2]]), b = Matrix([[4], [-8]])

**정답**

```json
"{(16 - 4*tau0, 9*tau0 - 36, tau0)}"
```

## 6. 시작 seed 40 (실제 seed 41)

[전체 JSON](start_40_actual_41.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[1, 0, -2], [-3, 1, 4]]), b = Matrix([[1], [0]])

**정답**

```json
"{(2*tau0 + 1, 2*tau0 + 3, tau0)}"
```

## 7. 시작 seed 42 (실제 seed 45)

[전체 JSON](start_42_actual_45.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[-1, 1, 2], [-1, -4, -1]]), b = Matrix([[2], [-8]])

**정답**

```json
"{(7*tau0/5, 2 - 3*tau0/5, tau0)}"
```

## 8. 시작 seed 46 (실제 seed 46)

[전체 JSON](start_46_actual_46.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[-4, 1, -5], [4, 4, -2]]), b = Matrix([[8], [-4]])

**정답**

```json
"{(-9*tau0/10 - 9/5, 7*tau0/5 + 4/5, tau0)}"
```

## 9. 시작 seed 47 (실제 seed 47)

[전체 JSON](start_47_actual_47.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[0, -4, 1], [3, 2, 4]]), b = Matrix([[2], [0]])

**정답**

```json
"{(1/3 - 3*tau0/2, tau0/4 - 1/2, tau0)}"
```

## 10. 시작 seed 48 (실제 seed 50)

[전체 JSON](start_48_actual_50.json)

**문제**

연립방정식 A x = b의 해를 벡터 매개변수형으로 나타내시오.
A = Matrix([[2, -1, 0], [5, -2, 2]]), b = Matrix([[2], [-6]])

**정답**

```json
"{(-2*tau0 - 10, -4*tau0 - 22, tau0)}"
```
