# 선형대수 문제 검수본

Template: `linear_algebra.la_05_eigenvalues_diagonalization.la.eigen.eigenvector.eigenvector_calculation.v1`

## 1. 시작 seed 17 (실제 seed 19)

[전체 JSON](start_17_actual_19.json)

**문제**

행렬 A의 고윳값 lambda=7에 대응하는 고유공간의 기저를 구하시오.
A = Matrix([[3, -4], [-4, 3]])

**정답**

```json
[
  [
    [
      -1
    ],
    [
      1
    ]
  ]
]
```

## 10. 시작 seed 28 (실제 seed 30)

[전체 JSON](start_28_actual_30.json)

**문제**

행렬 A의 고윳값 lambda=11에 대응하는 고유공간의 기저를 구하시오.
A = Matrix([[4, -5, 4], [-5, 5, -2], [4, -2, -1]])

**정답**

```json
[
  [
    [
      2
    ],
    [
      -2
    ],
    [
      1
    ]
  ]
]
```
