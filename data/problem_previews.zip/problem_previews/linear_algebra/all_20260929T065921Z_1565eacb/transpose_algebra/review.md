# 선형대수 문제 검수본

Template: `linear_algebra.la_01_matrix_algebra.la.matrix.transpose_symmetric.transpose_algebra.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[3, 1, -1], [0, -1, -3]]), B = Matrix([[3, 5], [-1, -4], [-5, -2]])

**정답**

```json
[
  [
    13,
    16
  ],
  [
    13,
    10
  ]
]
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[-3, -4, 5], [2, 0, -2]]), B = Matrix([[-2, 2], [5, 2], [-3, 2]])

**정답**

```json
[
  [
    -29,
    2
  ],
  [
    -4,
    0
  ]
]
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[5, -5, 3], [-4, 3, -2]]), B = Matrix([[1, 0], [3, -1], [4, -3]])

**정답**

```json
[
  [
    2,
    -3
  ],
  [
    -4,
    3
  ]
]
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[5, -3, -1], [5, 5, -4]]), B = Matrix([[0, 4], [-3, -5], [1, 1]])

**정답**

```json
[
  [
    8,
    -19
  ],
  [
    34,
    -9
  ]
]
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[-3, 1, 1], [5, -1, 2]]), B = Matrix([[-2, 2], [3, -3], [3, 3]])

**정답**

```json
[
  [
    12,
    -7
  ],
  [
    -6,
    19
  ]
]
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[-3, -2, -5], [4, 2, -3]]), B = Matrix([[-4, 5], [0, -4], [-2, -1]])

**정답**

```json
[
  [
    22,
    -10
  ],
  [
    -2,
    15
  ]
]
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[-1, -4, -5], [4, -1, 1]]), B = Matrix([[1, 3], [0, -3], [-2, -1]])

**정답**

```json
[
  [
    9,
    2
  ],
  [
    14,
    14
  ]
]
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[1, 4, -3], [-2, -3, -2]]), B = Matrix([[-3, 5], [5, -4], [-3, -1]])

**정답**

```json
[
  [
    26,
    -3
  ],
  [
    -8,
    4
  ]
]
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[1, -5, -2], [-1, 5, 2]]), B = Matrix([[-5, -1], [-5, -1], [4, 1]])

**정답**

```json
[
  [
    12,
    -12
  ],
  [
    2,
    -2
  ]
]
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

주어진 A, B에 대하여 (AB)^T를 계산하시오.
A = Matrix([[-2, 5, -2], [1, 4, 3]]), B = Matrix([[-5, -3], [2, -5], [5, 4]])

**정답**

```json
[
  [
    10,
    18
  ],
  [
    -27,
    -11
  ]
]
```
