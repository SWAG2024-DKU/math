# 선형대수 문제 검수본

Template: `linear_algebra.la_03_linear_transformations_determinants.la.determinant.triangular_block.block_matrix_determinant.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[0, 1, 0], [-2, 4, 0], [-3, -4, -1]]), C = Matrix([[2, 0, 4], [1, 2, -2], [4, -4, -2]])

**정답**

```json
144
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[-3, 3], [1, -1]]), C = Matrix([[3, 3], [-2, 3]])

**정답**

```json
0
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[4, -3], [4, -1]]), C = Matrix([[1, 4, 0], [-2, 0, -3], [0, 2, 1]])

**정답**

```json
112
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[0, -3], [1, -2]]), C = Matrix([[2, 2], [-3, -3]])

**정답**

```json
0
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[2, 2], [0, 3]]), C = Matrix([[3, 4], [-2, 4]])

**정답**

```json
120
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[-1, -4], [3, -2]]), C = Matrix([[1, -3], [-1, 0]])

**정답**

```json
-42
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[-3, -4, 0], [2, 2, 4], [1, -2, -1]]), C = Matrix([[3, -4, -1], [3, -4, -3], [-3, 3, 2]])

**정답**

```json
252
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[-2, -1, -2], [-1, -2, -3], [-2, 0, -4]]), C = Matrix([[3, -3, -4], [4, -2, 3], [3, 0, 3]])

**정답**

```json
330
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[-4, -1, 0], [3, -4, 0], [-4, 0, 2]]), C = Matrix([[-3, -1], [4, 1]])

**정답**

```json
38
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

블록 대각행렬 A = diag(B,C)의 행렬식을 구하시오.
B = Matrix([[-1, 2], [4, -4]]), C = Matrix([[3, -4], [4, -2]])

**정답**

```json
-40
```
