# 선형대수 문제 검수본

Template: `linear_algebra.la_03_linear_transformations_determinants.la.determinant.ero.determinant_by_ero.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[-1, 0, -1], [-3, 3, 5], [-1, -4, -5]])

**정답**

```json
-20
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[-4, 5], [2, 0]])

**정답**

```json
-10
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[3, -4], [3, -2]])

**정답**

```json
6
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[-1, 5], [5, -4]])

**정답**

```json
-21
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[1, 1], [5, -1]])

**정답**

```json
-6
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[-2, -5], [4, 2]])

**정답**

```json
16
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[-4, -5, 4], [-1, 1, 1], [3, 0, -3]])

**정답**

```json
0
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[4, -3, -2], [-3, -2, -3], [5, 5, -4]])

**정답**

```json
183
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[-5, -2, -1], [5, 2, -5], [-1, -5, -1]])

**정답**

```json
138
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

기본행연산과 행렬식의 변화 규칙을 이용하여 det(A)를 구하시오.
A = Matrix([[5, -2], [1, 4]])

**정답**

```json
22
```
