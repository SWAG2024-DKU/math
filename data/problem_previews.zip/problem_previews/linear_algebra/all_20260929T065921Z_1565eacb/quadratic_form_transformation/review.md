# 선형대수 문제 검수본

Template: `linear_algebra.la_05_eigenvalues_diagonalization.la.eigen.quadratic_forms.quadratic_form_transformation.v1`

## 1. 시작 seed 17 (실제 seed 78)

[전체 JSON](start_17_actual_78.json)

**문제**

대칭행렬 A가 정의하는 이차형식 x^T A x를 주축 좌표계에서 대각형식으로 나타내시오.
A = Matrix([[-3, 0], [0, 2]])

**정답**

```json
"-3*y1**2 + 2*y2**2"
```
