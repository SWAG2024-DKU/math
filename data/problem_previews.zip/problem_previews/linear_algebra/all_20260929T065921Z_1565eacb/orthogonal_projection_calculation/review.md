# 선형대수 문제 검수본

Template: `linear_algebra.la_04_orthogonality_optimization.la.ortho.projection.orthogonal_projection_calculation.v1`

## 1. 시작 seed 17 (실제 seed 18)

[전체 JSON](start_17_actual_18.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[-5], [4]]), b = Matrix([[1], [-1]])

**정답**

```json
[
  [
    "-9/2"
  ],
  [
    "9/2"
  ]
]
```

## 2. 시작 seed 19 (실제 seed 21)

[전체 JSON](start_19_actual_21.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[0], [5]]), b = Matrix([[0], [4]])

**정답**

```json
[
  [
    0
  ],
  [
    5
  ]
]
```

## 3. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[-3], [-6]]), b = Matrix([[3], [1]])

**정답**

```json
[
  [
    "-9/2"
  ],
  [
    "-3/2"
  ]
]
```

## 4. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[-5], [-6], [3]]), b = Matrix([[-2], [0], [0]])

**정답**

```json
[
  [
    -5
  ],
  [
    0
  ],
  [
    0
  ]
]
```

## 5. 시작 seed 24 (실제 seed 26)

[전체 JSON](start_24_actual_26.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[4], [-3]]), b = Matrix([[0], [3]])

**정답**

```json
[
  [
    0
  ],
  [
    -3
  ]
]
```

## 6. 시작 seed 27 (실제 seed 28)

[전체 JSON](start_27_actual_28.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[5], [-4]]), b = Matrix([[2], [3]])

**정답**

```json
[
  [
    "-4/13"
  ],
  [
    "-6/13"
  ]
]
```

## 7. 시작 seed 29 (실제 seed 31)

[전체 JSON](start_29_actual_31.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[1], [-5]]), b = Matrix([[6], [0]])

**정답**

```json
[
  [
    1
  ],
  [
    0
  ]
]
```

## 8. 시작 seed 32 (실제 seed 35)

[전체 JSON](start_32_actual_35.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[6], [-4], [5]]), b = Matrix([[-1], [-4], [-2]])

**정답**

```json
[
  [
    0
  ],
  [
    0
  ],
  [
    0
  ]
]
```

## 9. 시작 seed 36 (실제 seed 39)

[전체 JSON](start_36_actual_39.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[-2], [0]]), b = Matrix([[-6], [-3]])

**정답**

```json
[
  [
    "-8/5"
  ],
  [
    "-4/5"
  ]
]
```

## 10. 시작 seed 40 (실제 seed 42)

[전체 JSON](start_40_actual_42.json)

**문제**

벡터 a를 벡터 b가 생성하는 직선 위로 직교사영한 proj_b(a)를 구하시오.
a = Matrix([[-6], [5]]), b = Matrix([[-2], [-3]])

**정답**

```json
[
  [
    "6/13"
  ],
  [
    "9/13"
  ]
]
```
