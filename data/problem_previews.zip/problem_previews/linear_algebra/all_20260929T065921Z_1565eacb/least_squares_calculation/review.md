# 선형대수 문제 검수본

Template: `linear_algebra.la_04_orthogonality_optimization.la.ortho.least_squares.least_squares_calculation.v1`

## 1. 시작 seed 17 (실제 seed 19)

[전체 JSON](start_17_actual_19.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[3, -4], [3, -2], [1, 0]]), b = Matrix([[8], [1], [-4]])

**정답**

```json
[
  [
    "-19/7"
  ],
  [
    "-29/7"
  ]
]
```

## 2. 시작 seed 20 (실제 seed 25)

[전체 JSON](start_20_actual_25.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[-5, -2], [-1, 5], [2, -5], [-1, -5]]), b = Matrix([[1], [5], [-5], [-5]])

**정답**

```json
[
  [
    "-15/31"
  ],
  [
    "73/79"
  ]
]
```

## 3. 시작 seed 26 (실제 seed 27)

[전체 JSON](start_26_actual_27.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[-1, -1], [-2, -4], [-4, -1], [3, 0]]), b = Matrix([[0], [3], [4], [-3]])

**정답**

```json
[
  [
    "-50/53"
  ],
  [
    "-11/53"
  ]
]
```

## 4. 시작 seed 28 (실제 seed 28)

[전체 JSON](start_28_actual_28.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[-3, 3], [4, -3], [-2, -3]]), b = Matrix([[6], [5], [-2]])

**정답**

```json
[
  [
    "33/62"
  ],
  [
    "39/62"
  ]
]
```

## 5. 시작 seed 29 (실제 seed 29)

[전체 JSON](start_29_actual_29.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[0, 4], [4, -1], [-4, 3]]), b = Matrix([[3], [4], [5]])

**정답**

```json
[
  [
    "11/24"
  ],
  [
    "7/6"
  ]
]
```

## 6. 시작 seed 30 (실제 seed 38)

[전체 JSON](start_30_actual_38.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[1, -4], [-4, 0], [2, 0], [-5, 4]]), b = Matrix([[-3], [3], [2], [0]])

**정답**

```json
[
  [
    "-1/14"
  ],
  [
    "9/28"
  ]
]
```

## 7. 시작 seed 39 (실제 seed 42)

[전체 JSON](start_39_actual_42.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[-5, -1], [-2, -2], [-3, -4]]), b = Matrix([[-6], [5], [-7]])

**정답**

```json
[
  [
    1
  ],
  [
    "1/7"
  ]
]
```

## 8. 시작 seed 43 (실제 seed 53)

[전체 JSON](start_43_actual_53.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[2, 3], [2, 3], [0, 2]]), b = Matrix([[-8], [-7], [-3]])

**정답**

```json
[
  [
    "-3/2"
  ],
  [
    "-3/2"
  ]
]
```

## 9. 시작 seed 54 (실제 seed 54)

[전체 JSON](start_54_actual_54.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[2, 3], [-1, 2], [2, 1]]), b = Matrix([[-1], [6], [2]])

**정답**

```json
[
  [
    "-61/45"
  ],
  [
    "41/30"
  ]
]
```

## 10. 시작 seed 55 (실제 seed 61)

[전체 JSON](start_55_actual_61.json)

**문제**

과결정계 A x ≈ b의 최소제곱해 x_hat을 구하시오.
A = Matrix([[-3, 3], [-2, 0], [-1, 0], [-5, 2]]), b = Matrix([[3], [3], [-6], [4]])

**정답**

```json
[
  [
    "-27/73"
  ],
  [
    "56/73"
  ]
]
```
