# 선형대수 문제 검수본

Template: `linear_algebra.la_02_vector_spaces.la.space.basis.basis_verification.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

V의 열벡터들이 R^5의 기저인지 판정하시오.
V = Matrix([[1, -1, 0, -1, -3], [3, 5, -1, -4, -5], [-2, 1, 1, -1, 3], [0, 5, 5, 1, -3], [3, -5, -3, -2, -3]])

**정답**

```json
true
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

V의 열벡터들이 R^2의 기저인지 판정하시오.
V = Matrix([[-4, 5], [2, 0]])

**정답**

```json
true
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

V의 열벡터들이 R^1의 기저인지 판정하시오.
V = Matrix([[3]])

**정답**

```json
true
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

V의 열벡터들이 R^2의 기저인지 판정하시오.
V = Matrix([[-1, 5], [5, -4]])

**정답**

```json
true
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

V의 열벡터들이 R^2의 기저인지 판정하시오.
V = Matrix([[1, 1], [5, -1]])

**정답**

```json
true
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

V의 열벡터들이 R^2의 기저인지 판정하시오.
V = Matrix([[-2, -5], [4, 2]])

**정답**

```json
true
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

V의 열벡터들이 R^3의 기저인지 판정하시오.
V = Matrix([[-4, -5, 4], [-1, 1, 1], [3, 0, -3]])

**정답**

```json
false
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

V의 열벡터들이 R^4의 기저인지 판정하시오.
V = Matrix([[4, -3, -2, -3], [-2, -3, 5, 5], [-4, -3, -1, -5], [2, 2, 5, -4]])

**정답**

```json
true
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

V의 열벡터들이 R^4의 기저인지 판정하시오.
V = Matrix([[-5, -2, -1, 5], [2, -5, -1, -5], [-1, 4, 1, -4], [4, -4, 4, 5]])

**정답**

```json
true
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

V의 열벡터들이 R^2의 기저인지 판정하시오.
V = Matrix([[5, -2], [1, 4]])

**정답**

```json
true
```

## 11. 시작 seed 27 (실제 seed 27)

[전체 JSON](start_27_actual_27.json)

**문제**

V의 열벡터들이 R^4의 기저인지 판정하시오.
V = Matrix([[-1, -1, -2, -4], [-4, -1, 3, 0], [-1, 0, 1, -3], [-2, -2, 2, -4]])

**정답**

```json
true
```

## 12. 시작 seed 28 (실제 seed 28)

[전체 JSON](start_28_actual_28.json)

**문제**

V의 열벡터들이 R^1의 기저인지 판정하시오.
V = Matrix([[-3]])

**정답**

```json
true
```

## 13. 시작 seed 29 (실제 seed 29)

[전체 JSON](start_29_actual_29.json)

**문제**

V의 열벡터들이 R^5의 기저인지 판정하시오.
V = Matrix([[-4, 0, 4, 4, -1], [-4, 3, 0, 1, 1], [-5, -5, -4, 2, 5], [-2, 0, -4, 2, 0], [4, 3, 1, -2, 2]])

**정답**

```json
true
```

## 14. 시작 seed 30 (실제 seed 30)

[전체 JSON](start_30_actual_30.json)

**문제**

V의 열벡터들이 R^5의 기저인지 판정하시오.
V = Matrix([[-1, 4, -5, 4, 5], [-2, -1, -5, 1, 1], [5, -3, -4, 2, -5], [3, -2, -5, -4, -3], [4, 3, 1, 5, 0]])

**정답**

```json
true
```

## 15. 시작 seed 31 (실제 seed 31)

[전체 JSON](start_31_actual_31.json)

**문제**

V의 열벡터들이 R^1의 기저인지 판정하시오.
V = Matrix([[2]])

**정답**

```json
true
```

## 16. 시작 seed 32 (실제 seed 32)

[전체 JSON](start_32_actual_32.json)

**문제**

V의 열벡터들이 R^1의 기저인지 판정하시오.
V = Matrix([[-2]])

**정답**

```json
true
```

## 17. 시작 seed 33 (실제 seed 33)

[전체 JSON](start_33_actual_33.json)

**문제**

V의 열벡터들이 R^5의 기저인지 판정하시오.
V = Matrix([[-3, 5, -2, -1, 2], [5, 3, 3, -3, 5], [4, 3, 0, 5, 3], [2, 2, -1, 5, 5], [-4, -1, 1, -1, 3]])

**정답**

```json
true
```

## 18. 시작 seed 34 (실제 seed 34)

[전체 JSON](start_34_actual_34.json)

**문제**

V의 열벡터들이 R^5의 기저인지 판정하시오.
V = Matrix([[0, 4, -5, -2, -5], [1, 0, -4, 1, -1], [0, -4, 4, 3, -3], [-4, -1, 0, 4, -5], [-3, 3, -4, -5, 0]])

**정답**

```json
true
```

## 19. 시작 seed 35 (실제 seed 35)

[전체 JSON](start_35_actual_35.json)

**문제**

V의 열벡터들이 R^5의 기저인지 판정하시오.
V = Matrix([[0, -3, 0, -3, -1], [1, -1, 4, -5, 3], [-1, 5, 0, 4, -4], [0, -5, 3, -5, -4], [2, 0, -5, 0, 5]])

**정답**

```json
true
```

## 20. 시작 seed 36 (실제 seed 36)

[전체 JSON](start_36_actual_36.json)

**문제**

V의 열벡터들이 R^3의 기저인지 판정하시오.
V = Matrix([[-5, -5, -1], [-4, -5, 3], [5, -3, -2]])

**정답**

```json
true
```
