# calculus_1 문제 검수본

Template: `calculus_1.calc1_ch04_applications_of_differentiation.calculus.concavity_and_second_derivative_test.curve_sketching.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

f(x)=9(x-6)³+4의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, 6)"
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

f(x)=3(x-4)³+1의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, 4)"
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

f(x)=11(x-6)³+1의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, 6)"
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

f(x)=12(x-6)³+6의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, 6)"
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

f(x)=3(x-5)³+4의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, 5)"
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

f(x)=3(x--6)³+2의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, -6)"
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

f(x)=5(x--6)³+1의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, -6)"
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

f(x)=12(x-3)³+4의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, 3)"
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

f(x)=7(x--3)³+1의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, -3)"
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

f(x)=12(x-4)³+2의 그래프를 분석하시오. 스케치의 핵심인 아래로 오목한 구간(f''<0)만 답하시오.

**정답**

```json
"Interval.open(-oo, 4)"
```
