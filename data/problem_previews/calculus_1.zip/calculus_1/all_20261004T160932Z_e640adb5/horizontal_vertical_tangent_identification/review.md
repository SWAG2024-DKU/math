# calculus_1 문제 검수본

Template: `calculus_1.calc1_ch09_parametric_equations_and_polar_coordinates.calculus.parametric_tangent_line.horizontal_vertical_tangent_identification.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

X(t)=t², Y(t)=9t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

X(t)=t², Y(t)=3t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

X(t)=t², Y(t)=11t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

X(t)=t², Y(t)=12t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 5. 시작 seed 21 (실제 seed 23)

[전체 JSON](start_21_actual_23.json)

**문제**

X(t)=t², Y(t)=5t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 6. 시작 seed 24 (실제 seed 25)

[전체 JSON](start_24_actual_25.json)

**문제**

X(t)=t², Y(t)=7t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 7. 시작 seed 26 (실제 seed 28)

[전체 JSON](start_26_actual_28.json)

**문제**

X(t)=t², Y(t)=2t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 8. 시작 seed 29 (실제 seed 31)

[전체 JSON](start_29_actual_31.json)

**문제**

X(t)=t², Y(t)=1t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 9. 시작 seed 32 (실제 seed 33)

[전체 JSON](start_32_actual_33.json)

**문제**

X(t)=t², Y(t)=10t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```

## 10. 시작 seed 34 (실제 seed 36)

[전체 JSON](start_34_actual_36.json)

**문제**

X(t)=t², Y(t)=6t인 곡선의 수직접선이 생기는 t 값들의 집합을 구하시오.

**정답**

```json
"{0}"
```
