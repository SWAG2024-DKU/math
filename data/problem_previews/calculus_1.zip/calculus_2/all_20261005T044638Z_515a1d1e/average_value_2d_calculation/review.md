# calculus_2 문제 검수본

Template: `calculus_2.calc2_v3_ch05_multiple_integration.calculus.double_integral_over_rectangle.average_value_2d_calculation.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

[0,9]×[0,4]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
"13/2"
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

[0,3]×[0,1]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
2
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

[0,11]×[0,1]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
6
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

[0,12]×[0,6]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
9
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

[0,3]×[0,4]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
"7/2"
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

[0,3]×[0,2]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
"5/2"
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

[0,5]×[0,1]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
3
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

[0,12]×[0,4]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
8
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

[0,7]×[0,1]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
4
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

[0,12]×[0,2]에서 f=x+y의 평균값을 구하시오.

**정답**

```json
7
```
