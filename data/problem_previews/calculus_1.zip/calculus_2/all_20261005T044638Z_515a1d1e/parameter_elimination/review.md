# calculus_2 문제 검수본

Template: `calculus_2.calc2_v2_ch07_parametric_equations_and_polar_coordinates.calculus.parameter_elimination_and_line_parametrization.parameter_elimination.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

X(t)=9t, Y(t)=4t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, 4*x**2/81)"
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

X(t)=3t, Y(t)=1t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, x**2/9)"
```

## 3. 시작 seed 19 (실제 seed 20)

[전체 JSON](start_19_actual_20.json)

**문제**

X(t)=12t, Y(t)=6t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, x**2/24)"
```

## 4. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

X(t)=3t, Y(t)=4t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, 4*x**2/9)"
```

## 5. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

X(t)=3t, Y(t)=2t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, 2*x**2/9)"
```

## 6. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

X(t)=5t, Y(t)=1t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, x**2/25)"
```

## 7. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

X(t)=12t, Y(t)=4t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, x**2/36)"
```

## 8. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

X(t)=7t, Y(t)=1t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, x**2/49)"
```

## 9. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

X(t)=12t, Y(t)=2t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, x**2/72)"
```

## 10. 시작 seed 27 (실제 seed 28)

[전체 JSON](start_27_actual_28.json)

**문제**

X(t)=2t, Y(t)=6t²에서 t를 제거하여 y,x 방정식을 구하시오.

**정답**

```json
"Eq(y, 3*x**2/2)"
```
