# calculus_2 문제 검수본

Template: `calculus_2.calc2_v3_ch02_vectors_in_space.calculus.scalar_triple_product.coplanarity_check.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

u=(9,0,0), v=(0,4,0), w=(1,1,0)가 동일 평면에 놓이는가?

**정답**

```json
true
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

u=(3,0,0), v=(0,1,0), w=(1,1,0)가 동일 평면에 놓이는가?

**정답**

```json
true
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

u=(11,0,0), v=(0,1,0), w=(1,1,2)가 동일 평면에 놓이는가?

**정답**

```json
false
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

u=(12,0,0), v=(0,6,0), w=(1,1,0)가 동일 평면에 놓이는가?

**정답**

```json
true
```

## 5. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

u=(3,0,0), v=(0,4,0), w=(1,1,0)가 동일 평면에 놓이는가?

**정답**

```json
true
```

## 6. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

u=(3,0,0), v=(0,2,0), w=(1,1,2)가 동일 평면에 놓이는가?

**정답**

```json
false
```

## 7. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

u=(5,0,0), v=(0,1,0), w=(1,1,2)가 동일 평면에 놓이는가?

**정답**

```json
false
```

## 8. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

u=(12,0,0), v=(0,4,0), w=(1,1,-1)가 동일 평면에 놓이는가?

**정답**

```json
false
```

## 9. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

u=(7,0,0), v=(0,1,0), w=(1,1,0)가 동일 평면에 놓이는가?

**정답**

```json
true
```

## 10. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

u=(12,0,0), v=(0,2,0), w=(1,1,1)가 동일 평면에 놓이는가?

**정답**

```json
false
```
