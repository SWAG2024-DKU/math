# calculus_2 문제 검수본

Template: `calculus_2.calc2_v2_ch06_power_series.calculus.power_series_algebra.coefficient_determination.v1`

## 1. 시작 seed 17 (실제 seed 17)

[전체 JSON](start_17_actual_17.json)

**문제**

∑(9x)^n (n≥0)의 x^2 계수를 구하시오.

**정답**

```json
81
```

## 2. 시작 seed 18 (실제 seed 18)

[전체 JSON](start_18_actual_18.json)

**문제**

∑(3x)^n (n≥0)의 x^2 계수를 구하시오.

**정답**

```json
9
```

## 3. 시작 seed 19 (실제 seed 19)

[전체 JSON](start_19_actual_19.json)

**문제**

∑(11x)^n (n≥0)의 x^3 계수를 구하시오.

**정답**

```json
1331
```

## 4. 시작 seed 20 (실제 seed 20)

[전체 JSON](start_20_actual_20.json)

**문제**

∑(12x)^n (n≥0)의 x^3 계수를 구하시오.

**정답**

```json
1728
```

## 5. 시작 seed 21 (실제 seed 23)

[전체 JSON](start_21_actual_23.json)

**문제**

∑(5x)^n (n≥0)의 x^3 계수를 구하시오.

**정답**

```json
125
```

## 6. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

∑(12x)^n (n≥0)의 x^2 계수를 구하시오.

**정답**

```json
144
```

## 7. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

∑(7x)^n (n≥0)의 x^2 계수를 구하시오.

**정답**

```json
49
```

## 8. 시작 seed 26 (실제 seed 27)

[전체 JSON](start_26_actual_27.json)

**문제**

∑(11x)^n (n≥0)의 x^2 계수를 구하시오.

**정답**

```json
121
```

## 9. 시작 seed 28 (실제 seed 28)

[전체 JSON](start_28_actual_28.json)

**문제**

∑(2x)^n (n≥0)의 x^2 계수를 구하시오.

**정답**

```json
4
```

## 10. 시작 seed 29 (실제 seed 30)

[전체 JSON](start_29_actual_30.json)

**문제**

∑(9x)^n (n≥0)의 x^3 계수를 구하시오.

**정답**

```json
729
```
