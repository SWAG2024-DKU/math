# calculus_2 문제 검수본

Template: `calculus_2.calc2_v3_ch04_differentiation_of_functions_of_several_variables.calculus.directional_derivative_and_gradient.max_increase_direction_calculation.v1`

## 1. 시작 seed 17 (실제 seed 18)

[전체 JSON](start_17_actual_18.json)

**문제**

f(x,y,z)=3x+1y+4z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "3*sqrt(26)/26"
  ],
  [
    "sqrt(26)/26"
  ],
  [
    "2*sqrt(26)/13"
  ]
]
```

## 2. 시작 seed 19 (실제 seed 20)

[전체 JSON](start_19_actual_20.json)

**문제**

f(x,y,z)=12x+6y+2z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "3*sqrt(46)/23"
  ],
  [
    "3*sqrt(46)/46"
  ],
  [
    "sqrt(46)/46"
  ]
]
```

## 3. 시작 seed 21 (실제 seed 21)

[전체 JSON](start_21_actual_21.json)

**문제**

f(x,y,z)=3x+4y+4z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "3*sqrt(41)/41"
  ],
  [
    "4*sqrt(41)/41"
  ],
  [
    "4*sqrt(41)/41"
  ]
]
```

## 4. 시작 seed 22 (실제 seed 22)

[전체 JSON](start_22_actual_22.json)

**문제**

f(x,y,z)=3x+2y+1z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "3*sqrt(14)/14"
  ],
  [
    "sqrt(14)/7"
  ],
  [
    "sqrt(14)/14"
  ]
]
```

## 5. 시작 seed 23 (실제 seed 23)

[전체 JSON](start_23_actual_23.json)

**문제**

f(x,y,z)=5x+1y+1z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "5*sqrt(3)/9"
  ],
  [
    "sqrt(3)/9"
  ],
  [
    "sqrt(3)/9"
  ]
]
```

## 6. 시작 seed 24 (실제 seed 24)

[전체 JSON](start_24_actual_24.json)

**문제**

f(x,y,z)=12x+4y+2z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "6*sqrt(41)/41"
  ],
  [
    "2*sqrt(41)/41"
  ],
  [
    "sqrt(41)/41"
  ]
]
```

## 7. 시작 seed 25 (실제 seed 25)

[전체 JSON](start_25_actual_25.json)

**문제**

f(x,y,z)=7x+1y+2z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "7*sqrt(6)/18"
  ],
  [
    "sqrt(6)/18"
  ],
  [
    "sqrt(6)/9"
  ]
]
```

## 8. 시작 seed 26 (실제 seed 26)

[전체 JSON](start_26_actual_26.json)

**문제**

f(x,y,z)=12x+2y+2z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "3*sqrt(38)/19"
  ],
  [
    "sqrt(38)/38"
  ],
  [
    "sqrt(38)/38"
  ]
]
```

## 9. 시작 seed 27 (실제 seed 28)

[전체 JSON](start_27_actual_28.json)

**문제**

f(x,y,z)=2x+6y+2z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "sqrt(11)/11"
  ],
  [
    "3*sqrt(11)/11"
  ],
  [
    "sqrt(11)/11"
  ]
]
```

## 10. 시작 seed 29 (실제 seed 29)

[전체 JSON](start_29_actual_29.json)

**문제**

f(x,y,z)=9x+1y+3z의 최대 증가 방향 단위벡터를 구하시오.

**정답**

```json
[
  [
    "9*sqrt(91)/91"
  ],
  [
    "sqrt(91)/91"
  ],
  [
    "3*sqrt(91)/91"
  ]
]
```
