# 미적분 1 전체 Rule 검수 결과

총 201개. 결과: {'blocked': 144, 'applied': 56, 'preserved_existing': 1}
실행 검증 통과: 57개. 최종 사람 검수는 별도입니다.

자동 검수/생성 검증과 최종 사람 검수는 다릅니다. applied도 ready 또는 출제 승인 상태가 아닙니다.

| 유형 | 처리 | 실행 검사 | 원본 문제 | 적용 범위/남은 작업 |
|---|---|---|---|---|
| absolute_conditional_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| accumulation_function_derivative | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| alternating_series_error_estimation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| alternating_series_test_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| antiderivative_table_lookup | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다항식 공식표 |
| arc_length_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| arc_length_setup | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| area_between_curves_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 구간 내 위/아래 순서가 보장됨 |
| area_between_polar_curves | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| area_limit_estimation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 표본/수치적분/오차 허용 범위와 단위가 명시된 전용 계약 필요 |
| axis_distance_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| cancellation_verification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| cardiac_output_calculation | blocked | not_run | draft_auto/executable=True 모순 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 표본/수치적분/오차 허용 범위와 단위가 명시된 전용 계약 필요 |
| chain_rule_application | applied | passed | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| change_of_base | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| closed_interval_extrema_calculation | blocked | not_run | draft_auto/executable=True 모순 / 답 유형과 맞지 않는 Validator: numeric_sampling,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| comparison_series_construction | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| comparison_theorem_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| composition_continuity_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| composition_evaluation | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| concavity_interval_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: sign_chart_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| conic_element_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| conic_type_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| consumer_surplus_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 거래량 구간에서 음수가 아닌 선형 수요 |
| continuity_algebra_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| continuity_check | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다항식의 연속성 |
| critical_number_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: root_set_equivalence,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| cross_section_area_construction | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| curve_sketching | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: sign_chart_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| cylindrical_shell_volume_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| definite_integral_evaluation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| definite_integral_substitution | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | u=a*x²+b 치환 |
| derivative_at_point_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| derivative_from_definition | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| difference_quotient_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| differentiability_check | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 좌우 미분계수의 존재와 일치 검사; True/False 모두 생성 |
| differentiability_continuity_reasoning | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| direct_comparison_test_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| direct_substitution_limit | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| discontinuity_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| disk_method_volume | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 반지름이 양수인 직선 그래프 |
| displacement_and_distance_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| displacement_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| divergence_test_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| domain_by_family | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| domain_of_combination | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| domain_range_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| domain_segment_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| economic_optimization | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| error_propagation_estimation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 표본/수치적분/오차 허용 범위와 단위가 명시된 전용 계약 필요 |
| even_odd_classification | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 영함수는 우함수이면서 기함수이므로 두 계수 모두 0인 경우 제외 |
| evt_condition_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: root_set_equivalence,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| exponent_law_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| exponential_derivative_calculation | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| extrema_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: root_set_equivalence,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| first_derivative_test_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: sign_chart_check / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| function_decomposition | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| function_family_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| general_to_standard_form_conversion | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| geometric_sequence_limit_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| geometric_series_sum_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 샘플러의 수렴 기하급수족 |
| graph_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| graph_sketch_rule | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| growth_rate_comparison | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| heaviside_modeling | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| higher_derivative_calculation | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 2차 미분 |
| horizontal_asymptote_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| horizontal_tangent_point_calculation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| horizontal_vertical_tangent_identification | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| hydrostatic_force_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| hyperbolic_derivative_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | sinh의 지수 정의를 사용 |
| hyperbolic_identity_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| implicit_differentiation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| implicit_second_derivative | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| improper_integral_evaluation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 특이점/무한 구간/무한 결과를 구분하는 전용 계산 및 답 표현 정책 필요 |
| improper_integral_type_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| increasing_decreasing_interval_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: sign_chart_check / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| indefinite_integral_substitution | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | u=a*x²+b 치환 |
| indeterminate_form_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| indeterminate_form_resolution | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 약분 전 원식과 삭제된 점을 문제 문장에 명시 |
| infinite_limit_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| inflection_point_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: sign_chart_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| initial_value_problem | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다항식 원시함수의 적분상수 결정 |
| inner_outer_identification | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| instantaneous_velocity_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| integrability_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| integral_inequality_proof | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| integral_property_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| integral_test_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| integration_by_parts_application | applied | passed | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | u=x, dv=exp(a*x)dx |
| intersection_point_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| inverse_function_derivation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| inverse_function_derivative_rule_application | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| inverse_hyperbolic_derivative_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| inverse_trig_derivative_calculation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| inverse_trig_evaluation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| ivt_condition_check | blocked | not_run | draft_auto/executable=True 모순 / 답 유형과 맞지 않는 Validator: sign_chart_check / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| lhopital_application | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 0/0 꼴; 최종 값만 검증 |
| limit_at_infinity_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 특이점/무한 구간/무한 결과를 구분하는 전용 계산 및 답 표현 정책 필요 |
| limit_comparison_test_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| limit_existence_reasoning | applied | passed | draft_auto/executable=True 모순 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 최종 판정만 자동 검증; 설명은 사람 검수 |
| limit_law_application | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| limit_law_precondition_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| limit_numeric_estimation | blocked | not_run | draft_auto/executable=True 모순 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 표본/수치적분/오차 허용 범위와 단위가 명시된 전용 계약 필요 |
| linear_approximation_estimation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 선형화 값의 정확한 유리수 표현; 수치 참값 오차와 구분 |
| linearization_construction | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| log_derivative_calculation | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | x>0에서 자연로그 합성함수 |
| log_law_application | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| logarithmic_differentiation_application | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 양의 함수에서 로그 미분; 최종 답만 검증, 풀이 방법은 사람 검수 |
| midpoint_rule_estimation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 표본/수치적분/오차 허용 범위와 단위가 명시된 전용 계약 필요 |
| monotonic_interval_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| monotonic_theorem_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| monotonicity_boundedness_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| monotonicity_from_base | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| motion_reconstruction | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| mvt_bound_estimation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 표본/수치적분/오차 허용 범위와 단위가 명시된 전용 계약 필요 |
| mvt_point_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| natural_vs_common_log | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| net_change_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| numeric_integration_from_data | blocked | not_run | draft_auto/executable=True 모순 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 표본/수치적분/오차 허용 범위와 단위가 명시된 전용 계약 필요 |
| one_sided_limit_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| one_to_one_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| optimization_formulation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| optimization_solving | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| orientation_convention_application | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| p_series_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| pappus_applicability_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| pappus_theorem_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| parameter_elimination | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| parametric_arc_length_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| parametric_area_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| parametric_curve_sketching | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| parametric_second_derivative_calculation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| parametric_surface_area_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| parametric_tangent_slope_calculation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| partial_fraction_decomposition | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| partial_fraction_integration | applied | passed | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | x>0의 서로 다른 일차 인수 |
| piecewise_evaluation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| polar_arc_length_calculation | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| polar_area_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| polar_cartesian_conversion | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| polar_curve_identification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| polar_curve_intersection | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| polar_symmetry_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| polar_tangent_slope_calculation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| pole_tangent_calculation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| polynomial_differentiation | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 1~3차 다항식 |
| position_derivative_interpretation | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 시간 변수 x; 가속도 계산 |
| power_rule_application | preserved_existing | passed | 기존 구현 | 기존 구현 계약 보존 |
| producer_surplus_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 양수인 선형 공급 |
| product_rule_application | applied | passed | draft_auto/executable=True 모순 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| quotient_rule_application | applied | passed | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | x>0에서 분모가 0이 아닌 유리함수 |
| rate_of_change_interpretation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| ratio_test_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| rational_end_behavior_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| reciprocal_derivative | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| reciprocal_trig_evaluation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| recursive_sequence_limit_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| reduction_formula_application | applied | passed | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | sin의 작은 정수 거듭제곱; 풀이 단계는 사람 검수 |
| related_rates_equation_formulation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| related_rates_solving | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| remainder_estimation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 표본/수치적분/오차 허용 범위와 단위가 명시된 전용 계약 필요 |
| repeated_chain_rule | applied | passed | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 세 함수의 합성 |
| repeated_product_rule | applied | passed | draft_auto/executable=True 모순 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 세 인수의 곱 |
| riemann_sum_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| rolle_condition_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| root_interval_location | blocked | not_run | draft_auto/executable=True 모순 / 답 유형과 맞지 않는 Validator: sign_chart_check / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| root_test_application | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| secant_slope_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| second_derivative_test_classification | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: sign_chart_check,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| self_referential_integral_solving | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 반복 부분적분 |
| sequence_convergence_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| sequence_limit_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| shell_vs_disk_method_selection | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| squeeze_theorem_application | blocked | not_run | draft_auto/executable=True 모순 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| surface_area_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| surface_area_setup | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| symmetric_interval_shortcut | applied | passed | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | [-1,1]의 기함수/우함수 항 |
| tangent_line_derivation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| tangent_line_implicit | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 다변수/곡선 기하 조건과 유일한 답의 범위를 검사하는 전용 계약 필요 |
| tangent_line_via_derivative | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| tangent_normal_line_derivation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| tangent_slope_interpretation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| telescoping_series_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 수렴/발산/조건수렴과 판정법 적용 조건을 검사하는 전용 계약 필요 |
| test_selection_reasoning | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| transformation_identification | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| trig_derivative_calculation | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | sin/cos 조합 |
| trig_domain_range_period_identification | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| trig_integral_strategy_selection | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
| trig_limit_via_substitution | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| trig_power_integral_calculation | applied | passed | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | u=cos(x) 치환 |
| trig_substitution_integral_calculation | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| trig_substitution_selection | blocked | not_run | 정답 계산식 누락 / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| two_sided_limit_existence_check | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 문제 문장에 명시한 범위 |
| variable_bound_integral_derivative | blocked | not_run | 정답 계산식 누락 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| variable_choice_for_area | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| vertical_asymptote_calculation | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: symbolic_equivalence / symbolic_input 미구현 / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 특이점/무한 구간/무한 결과를 구분하는 전용 계산 및 답 표현 정책 필요 |
| vertical_line_test_check | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: domain_check,symbolic_equivalence / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 해당 문제 의도를 보존하는 전용 생성/검증 계약이 아직 없음 |
| volume_by_cross_section_calculation | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 단면 넓이 함수가 문제에 주어짐 |
| washer_method_volume | applied | passed | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_sampling / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 외반지름≥내반지름=1 |
| width_function_construction | blocked | not_run | 정답 계산식 누락 / 답 유형과 맞지 않는 Validator: numeric_tolerance / 문제 입력 조립식 누락 / 유형 이름만 있는 일반 문제 문장 | 판정/풀이/설정 문제의 유형별 답 형식과 전제조건 검증을 별도로 구현해야 함 |
